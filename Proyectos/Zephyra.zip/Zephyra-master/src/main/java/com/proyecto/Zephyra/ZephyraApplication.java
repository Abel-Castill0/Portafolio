package com.proyecto.Zephyra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZephyraApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZephyraApplication.class, args);
	}

}
