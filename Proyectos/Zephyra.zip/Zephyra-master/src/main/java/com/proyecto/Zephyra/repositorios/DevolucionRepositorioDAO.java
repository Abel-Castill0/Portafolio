package com.proyecto.Zephyra.repositorios;

import com.proyecto.Zephyra.model.Devolucion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DevolucionRepositorioDAO extends JpaRepository<Devolucion, Long>{
    
}
