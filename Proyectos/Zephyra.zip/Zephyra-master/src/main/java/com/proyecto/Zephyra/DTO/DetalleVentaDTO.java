package com.proyecto.Zephyra.DTO;

import lombok.Data;

@Data
public class DetalleVentaDTO {
    private Integer productoId;
    private Integer cantidad;
    private Double precio;
}
