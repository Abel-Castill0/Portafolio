package com.proyecto.Zephyra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZephyraApplicationTests {

	@Test
	void contextLoads() {
	}

}
